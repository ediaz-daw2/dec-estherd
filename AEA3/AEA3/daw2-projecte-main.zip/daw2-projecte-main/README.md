# daw2-projecte

Recordeu que falta el directori 'node_modules' cal crearlo:
```
npm install
```
